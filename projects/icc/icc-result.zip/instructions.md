# CSS Coding Challenge
Your task is to implement the included mockup in HTML and CSS and JS funcitons. You can use the
included index.html, style.css, and main.js files as a starting point if you wish.

The columns should be replaced with random quotes which can be pulled from the following API:
https://pprathameshmore.github.io/QuoteGarden

## Helpful hints

The font used in the mockup is Roboto, and is available on Google Fonts:

https://www.google.com/fonts
